
    // $(document).ready(function () {
    //     $('ul.sf-menu li').hoverIntent({
    //         sensitivity: 2, interval: 200, over: hoverover, timeout: 500, out: hoverout
    //     });
    //     $('ul.sf-menu li').hover(hoverover, hoverout);
    //     $('ul.sf-menu li .dropdown ul').makeacolumnlists({ cols: 2, colWidth: 180, equalHeight: false, startN: 1 });
    // });


$(document).ready(function () {

// MENU DROP DOWN

        var sfMenu = (function () {

            $('ul.sf-menu li').hoverIntent({sensitivity: 2, interval: 200, over: hoverover, timeout: 500, out: hoverout});
            $('ul.sf-menu li').hover(hoverover, hoverout);
            $('ul.sf-menu li .dropdown ul').makeacolumnlists({ cols: 2, colWidth: 180, equalHeight: false, startN: 1 });

        })();

// COUNTRY DROP DOWN        

    	var cdropDown = (function () {



             // Menu Over function call
        	function showcountries() {
            	$("#demo .tooltip").show();
        	}

        	// Menu Out function call
        	function hidecountries() {
            	$("#demo .tooltip").hide();
        	}

    		var config = {
    	        over: showcountries, // function = onMouseOver callback (REQUIRED)    
    	        timeout: 500, // number = milliseconds delay before onMouseOut    
    	        out: hidecountries // function = onMouseOut callback (REQUIRED)    
        		};

            $("#demo").hoverIntent(config);


    	})();

// SEGMENT DROP DOWN        

        var segmentdropDown = (function () {

             // Menu Over function call
            function showDemoTwo() {
                $("#demoTwo .tooltip").show();
                $("#demoTwo .tooltip").style.position = 'fixed';
            }

            // Menu Out function call
            function hideDemoTwo() {
                $("#demoTwo .tooltip").hide();
            }

            var config2 = {
                over: showDemoTwo, // function = onMouseOver callback (REQUIRED)    
                out: hideDemoTwo // function = onMouseOut callback (REQUIRED)    
            };

            $("#demoTwo").hoverIntent(config2);

        })();
		
}); // end of doc.ready

    
    
    